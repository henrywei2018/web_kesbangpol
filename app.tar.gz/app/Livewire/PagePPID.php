<?php

namespace App\Livewire;

use Livewire\Component;

class PagePPID extends Component
{
    public function render()
    {
        return view('livewire.page-p-p-i-d');
    }
}
