<?php

namespace App\Livewire;

use Livewire\Component;

class KontakComponent extends Component
{
    public function render()
    {
        return view('livewire.kontak-component');
    }
}
