<?php

namespace App\Livewire\Page\Ppid;

use Livewire\Component;

class Prosedur extends Component
{
    public function render()
    {
        return view('livewire.page.ppid.prosedur');
    }
}
