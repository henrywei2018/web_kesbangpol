<?php

namespace App\Livewire;

use Livewire\Component;

class ProfilOrganisasi extends Component
{
    public function render()
    {
        return view('livewire.profil-organisasi');
    }
}
