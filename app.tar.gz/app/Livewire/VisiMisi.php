<?php

namespace App\Livewire;

use Livewire\Component;

class VisiMisi extends Component
{
    public function render()
    {
        return view('livewire.visi-misi');
    }
}
