<?php

namespace App\Livewire\Widgets;

use Livewire\Component;

class WidgetBerita extends Component
{
    public function render()
    {
        return view('livewire.widgets.widget-berita');
    }
}
