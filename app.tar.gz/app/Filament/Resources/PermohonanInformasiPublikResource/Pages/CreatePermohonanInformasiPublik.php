<?php

namespace App\Filament\Resources\PermohonanInformasiPublikResource\Pages;

use App\Filament\Resources\PermohonanInformasiPublikResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePermohonanInformasiPublik extends CreateRecord
{
    protected static string $resource = PermohonanInformasiPublikResource::class;
}
