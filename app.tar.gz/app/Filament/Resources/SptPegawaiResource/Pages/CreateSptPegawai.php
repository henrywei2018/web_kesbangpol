<?php

namespace App\Filament\Resources\SptPegawaiResource\Pages;

use App\Filament\Resources\SptPegawaiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSptPegawai extends CreateRecord
{
    protected static string $resource = SptPegawaiResource::class;
}
