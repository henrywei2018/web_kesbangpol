<?php

namespace App\Filament\Resources\LaporATHGResource\Pages;

use App\Filament\Resources\LaporATHGResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLaporATHG extends CreateRecord
{
    protected static string $resource = LaporATHGResource::class;
}
