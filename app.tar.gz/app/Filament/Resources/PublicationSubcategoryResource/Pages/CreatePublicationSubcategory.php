<?php

namespace App\Filament\Resources\PublicationSubcategoryResource\Pages;

use App\Filament\Resources\PublicationSubcategoryResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePublicationSubcategory extends CreateRecord
{
    protected static string $resource = PublicationSubcategoryResource::class;
}
