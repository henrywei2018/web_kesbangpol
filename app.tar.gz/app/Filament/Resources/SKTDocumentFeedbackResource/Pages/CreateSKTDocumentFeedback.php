<?php

namespace App\Filament\Resources\SKTDocumentFeedbackResource\Pages;

use App\Filament\Resources\SKTDocumentFeedbackResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSKTDocumentFeedback extends CreateRecord
{
    protected static string $resource = SKTDocumentFeedbackResource::class;
}
