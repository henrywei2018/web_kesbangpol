<?php

namespace App\Filament\Resources\KonfigurasiAplikasiResource\Pages;

use App\Filament\Resources\KonfigurasiAplikasiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKonfigurasiAplikasi extends CreateRecord
{
    protected static string $resource = KonfigurasiAplikasiResource::class;
}
