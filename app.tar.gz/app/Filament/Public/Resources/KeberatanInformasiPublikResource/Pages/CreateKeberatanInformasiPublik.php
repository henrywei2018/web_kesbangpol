<?php

namespace App\Filament\Public\Resources\KeberatanInformasiPublikResource\Pages;

use App\Filament\Public\Resources\KeberatanInformasiPublikResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKeberatanInformasiPublik extends CreateRecord
{
    protected static string $resource = KeberatanInformasiPublikResource::class;
}
