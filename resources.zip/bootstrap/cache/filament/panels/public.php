<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.public.resources.keberatan-informasi-publik-resource.pages.create-keberatan-informasi-publik' => 'App\\Filament\\Public\\Resources\\KeberatanInformasiPublikResource\\Pages\\CreateKeberatanInformasiPublik',
    'app.filament.public.resources.keberatan-informasi-publik-resource.pages.edit-keberatan-informasi-publik' => 'App\\Filament\\Public\\Resources\\KeberatanInformasiPublikResource\\Pages\\EditKeberatanInformasiPublik',
    'app.filament.public.resources.keberatan-informasi-publik-resource.pages.list-keberatan-informasi-publiks' => 'App\\Filament\\Public\\Resources\\KeberatanInformasiPublikResource\\Pages\\ListKeberatanInformasiPubliks',
    'app.filament.public.resources.lapor-a-t-h-g-resource.pages.create-lapor-a-t-h-g' => 'App\\Filament\\Public\\Resources\\LaporATHGResource\\Pages\\CreateLaporATHG',
    'app.filament.public.resources.lapor-a-t-h-g-resource.pages.edit-lapor-a-t-h-g' => 'App\\Filament\\Public\\Resources\\LaporATHGResource\\Pages\\EditLaporATHG',
    'app.filament.public.resources.lapor-a-t-h-g-resource.pages.list-lapor-a-t-h-g-s' => 'App\\Filament\\Public\\Resources\\LaporATHGResource\\Pages\\ListLaporATHGS',
    'app.filament.public.resources.lapor-a-t-h-g-resource.pages.view-lapor-a-t-h-g' => 'App\\Filament\\Public\\Resources\\LaporATHGResource\\Pages\\ViewLaporATHG',
    'app.filament.public.resources.permohonan-informasi-publik-resource.pages.create-permohonan-informasi-publik' => 'App\\Filament\\Public\\Resources\\PermohonanInformasiPublikResource\\Pages\\CreatePermohonanInformasiPublik',
    'app.filament.public.resources.permohonan-informasi-publik-resource.pages.edit-permohonan-informasi-publik' => 'App\\Filament\\Public\\Resources\\PermohonanInformasiPublikResource\\Pages\\EditPermohonanInformasiPublik',
    'app.filament.public.resources.permohonan-informasi-publik-resource.pages.list-permohonan-informasi-publiks' => 'App\\Filament\\Public\\Resources\\PermohonanInformasiPublikResource\\Pages\\ListPermohonanInformasiPubliks',
    'app.filament.public.resources.s-k-l-resource.pages.create-s-k-l' => 'App\\Filament\\Public\\Resources\\SKLResource\\Pages\\CreateSKL',
    'app.filament.public.resources.s-k-l-resource.pages.edit-s-k-l' => 'App\\Filament\\Public\\Resources\\SKLResource\\Pages\\EditSKL',
    'app.filament.public.resources.s-k-l-resource.pages.list-s-k-ls' => 'App\\Filament\\Public\\Resources\\SKLResource\\Pages\\ListSKLs',
    'app.filament.public.resources.s-k-t-resource.pages.create-s-k-t' => 'App\\Filament\\Public\\Resources\\SKTResource\\Pages\\CreateSKT',
    'app.filament.public.resources.s-k-t-resource.pages.edit-s-k-t' => 'App\\Filament\\Public\\Resources\\SKTResource\\Pages\\EditSKT',
    'app.filament.public.resources.s-k-t-resource.pages.list-s-k-t-s' => 'App\\Filament\\Public\\Resources\\SKTResource\\Pages\\ListSKTS',
    'app.filament.public.pages.dashboard' => 'App\\Filament\\Public\\Pages\\Dashboard',
    'app.filament.public.pages.ormas-dashboard' => 'App\\Filament\\Public\\Pages\\OrmasDashboard',
    'app.filament.public.widgets.public-ormas-category-distribution' => 'App\\Filament\\Public\\Widgets\\PublicOrmasCategoryDistribution',
    'app.filament.public.widgets.public-ormas-detailed-stats' => 'App\\Filament\\Public\\Widgets\\PublicOrmasDetailedStats',
    'app.filament.public.widgets.public-ormas-regional-distribution' => 'App\\Filament\\Public\\Widgets\\PublicOrmasRegionalDistribution',
    'app.filament.public.widgets.public-ormas-stats-overview' => 'App\\Filament\\Public\\Widgets\\PublicOrmasStatsOverview',
    'app.filament.public.widgets.quick-actions' => 'App\\Filament\\Public\\Widgets\\QuickActions',
    'app.filament.public.widgets.recent-activity' => 'App\\Filament\\Public\\Widgets\\RecentActivity',
    'app.filament.public.widgets.stats-overview' => 'App\\Filament\\Public\\Widgets\\StatsOverview',
    'app.filament.public.widgets.system-status' => 'App\\Filament\\Public\\Widgets\\SystemStatus',
    'app.filament.public.widgets.welcome-card' => 'App\\Filament\\Public\\Widgets\\WelcomeCard',
    'jeffgreco13.filament-breezy.pages.my-profile-page' => 'Jeffgreco13\\FilamentBreezy\\Pages\\MyProfilePage',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Pages\\Dashboard.php' => 'App\\Filament\\Public\\Pages\\Dashboard',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Pages\\OrmasDashboard.php' => 'App\\Filament\\Public\\Pages\\OrmasDashboard',
    0 => 'App\\Filament\\Public\\Pages\\Dashboard',
    1 => 'App\\Filament\\Public\\Pages\\OrmasDashboard',
    2 => 'Jeffgreco13\\FilamentBreezy\\Pages\\MyProfilePage',
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament/Public/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Public\\Pages',
  ),
  'resources' => 
  array (
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Resources\\KeberatanInformasiPublikResource.php' => 'App\\Filament\\Public\\Resources\\KeberatanInformasiPublikResource',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Resources\\LaporATHGResource.php' => 'App\\Filament\\Public\\Resources\\LaporATHGResource',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Resources\\PermohonanInformasiPublikResource.php' => 'App\\Filament\\Public\\Resources\\PermohonanInformasiPublikResource',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Resources\\SKLResource.php' => 'App\\Filament\\Public\\Resources\\SKLResource',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Resources\\SKTResource.php' => 'App\\Filament\\Public\\Resources\\SKTResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament/Public/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Public\\Resources',
  ),
  'widgets' => 
  array (
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Widgets\\PublicOrmasCategoryDistribution.php' => 'App\\Filament\\Public\\Widgets\\PublicOrmasCategoryDistribution',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Widgets\\PublicOrmasDetailedStats.php' => 'App\\Filament\\Public\\Widgets\\PublicOrmasDetailedStats',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Widgets\\PublicOrmasRegionalDistribution.php' => 'App\\Filament\\Public\\Widgets\\PublicOrmasRegionalDistribution',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Widgets\\PublicOrmasStatsOverview.php' => 'App\\Filament\\Public\\Widgets\\PublicOrmasStatsOverview',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Widgets\\QuickActions.php' => 'App\\Filament\\Public\\Widgets\\QuickActions',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Widgets\\RecentActivity.php' => 'App\\Filament\\Public\\Widgets\\RecentActivity',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Widgets\\StatsOverview.php' => 'App\\Filament\\Public\\Widgets\\StatsOverview',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Widgets\\SystemStatus.php' => 'App\\Filament\\Public\\Widgets\\SystemStatus',
    'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament\\Public\\Widgets\\WelcomeCard.php' => 'App\\Filament\\Public\\Widgets\\WelcomeCard',
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\Master Web OPD\\web_kesbangpol\\app\\Filament/Public/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Public\\Widgets',
  ),
);