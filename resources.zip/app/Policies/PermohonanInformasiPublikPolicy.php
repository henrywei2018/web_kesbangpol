<?php

namespace App\Policies;

use App\Models\User;
use App\Models\PermohonanInformasiPublik;
use Illuminate\Auth\Access\HandlesAuthorization;

class PermohonanInformasiPublikPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user): bool
    {
        // Allow access for super_admin, admin, editor, and public users
        return $user->hasAnyRole(['super_admin', 'admin', 'editor', 'public']);
    }

    public function view(User $user, PermohonanInformasiPublik $model): bool
    {
        // Super admin can view all
        if ($user->hasRole('super_admin')) {
            return true;
        }
        
        // Public users can only view their own records
        if ($user->hasRole('public')) {
            return $model->user_id === $user->id;
        }
        
        // Admin and editor can view all
        return $user->hasAnyRole(['admin', 'editor']);
    }

    public function create(User $user): bool
    {
        // All authenticated users can create
        return $user->hasAnyRole(['super_admin', 'admin', 'editor', 'public']);
    }

    public function update(User $user, PermohonanInformasiPublik $model): bool
    {
        // Super admin can update all
        if ($user->hasRole('super_admin')) {
            return true;
        }
        
        // Public users can only update their own records if status allows
        if ($user->hasRole('public')) {
            $latestStatus = $model->statuses()->latest()->first();
            $status = $latestStatus ? $latestStatus->status : 'Pending';
            
            // Only allow updates if status is Pending
            return $model->user_id === $user->id && $status === 'Pending';
        }
        
        // Admin and editor can update all
        return $user->hasAnyRole(['admin', 'editor']);
    }

    public function delete(User $user, PermohonanInformasiPublik $model): bool
    {
        // Only super admin can delete
        return $user->hasRole('super_admin');
    }

    public function deleteAny(User $user): bool
    {
        return $user->hasRole('super_admin');
    }

    public function restore(User $user, PermohonanInformasiPublik $model): bool
    {
        return $user->hasRole('super_admin');
    }

    public function forceDelete(User $user, PermohonanInformasiPublik $model): bool
    {
        return $user->hasRole('super_admin');
    }
}