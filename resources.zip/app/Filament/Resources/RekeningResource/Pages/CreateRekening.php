<?php

namespace App\Filament\Resources\RekeningResource\Pages;

use App\Filament\Resources\RekeningResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRekening extends CreateRecord
{
    protected static string $resource = RekeningResource::class;
}
