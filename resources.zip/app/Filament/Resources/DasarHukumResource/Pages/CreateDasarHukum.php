<?php

namespace App\Filament\Resources\DasarHukumResource\Pages;

use App\Filament\Resources\DasarHukumResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDasarHukum extends CreateRecord
{
    protected static string $resource = DasarHukumResource::class;
}
