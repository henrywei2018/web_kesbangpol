<?php

namespace App\Livewire\Components;

use Livewire\Component;

class SearchForm extends Component
{
    public function render()
    {
        return view('livewire.components.search-form');
    }
}
