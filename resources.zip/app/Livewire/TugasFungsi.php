<?php

namespace App\Livewire;

use Livewire\Component;

class TugasFungsi extends Component
{
    public function render()
    {
        return view('livewire.tugas-fungsi');
    }
}
