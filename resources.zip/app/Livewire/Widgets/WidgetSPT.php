<?php

namespace App\Livewire\Widgets;

use Livewire\Component;

class WidgetSPT extends Component
{
    public function render()
    {
        return view('livewire.widgets.widget-s-p-t');
    }
}
