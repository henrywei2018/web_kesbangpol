<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Basic -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Badan Kesatuan Bangsa dan Politik Kaltara</title>

    <meta name="keywords" content="WebSite Template" />
    <meta name="description" content="Porto - Multipurpose Website Template">
    <meta name="author" content="okler.net">

    <!-- Favicon -->
    <link rel="shortcut icon" href="/assets/img/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="/assets/img/apple-touch-icon.png">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, shrink-to-fit=no">

    <!-- Web Fonts  -->
    <link id="googleFonts"
        href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800%7CShadows+Into+Light&display=swap"
        rel="stylesheet" type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="/assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/vendor/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="/assets/vendor/animate/animate.compat.css">
    <link rel="stylesheet" href="/assets/vendor/simple-line-icons/css/simple-line-icons.min.css">
    <link rel="stylesheet" href="/assets/vendor/owl.carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="/assets/vendor/owl.carousel/assets/owl.theme.default.min.css">
    <link rel="stylesheet" href="//assets/vendor/magnific-popup/magnific-popup.min.css">

    <!-- Theme CSS -->
    <link rel="stylesheet" href="/assets/css/theme.css">
    <link rel="stylesheet" href="/assets/css/theme-elements.css">
    <link rel="stylesheet" href="/assets/css/theme-blog.css">
    <link rel="stylesheet" href="/assets/css/theme-shop.css">

    <!-- Demo CSS -->
    <link rel="stylesheet" href="/assets/css/demos/demo-business-consulting-4.css">

    <!-- Skin CSS -->
    <link id="skinCSS" rel="stylesheet" href="/assets/css/skins/skin-business-consulting-4.css">

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="/assets/css/custom.css">

</head>

<body>

    <div class="body">
        <header id="header" class="header-transparent"
            data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': false, 'stickyChangeLogo': false, 'stickyStartAt': 53, 'stickySetTop': '-53px'}">
            <div class="header-body border-top-0 h-auto box-shadow-none">
                <div class="header-top header-top-borders">
                    <div class="container h-100">
                        <div class="header-row h-100">
                            <div class="header-column justify-content-start">
                                <div class="header-row">
                                    <nav class="header-nav-top">
                                        <ul class="nav nav-pills">
                                            <li class="nav-item py-2 d-none d-sm-inline-flex pe-2">
                                                <span class="ps-0 font-weight-semibold text-color-default text-2-5">Jl.
                                                    Bhayangkara Gg.3 RT.93 RW.35</span>
                                            </li>
                                            <li class="nav-item py-2 d-none d-md-inline-flex">
                                                <a href="kesbangpol.kaltara@gmail.com"
                                                    class="text-color-default text-2-5 text-color-hover-primary font-weight-semibold">kesbangpol.kaltara@gmail.com</a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <div class="header-column justify-content-end">
                                <div class="header-row">
                                    <nav class="header-nav-top">
                                        <ul class="nav nav-pills p-relative bottom-2">
                                            <li class="nav-item py-2 d-none d-lg-inline-flex">
                                                <a href="http://www.facebook.com/" target="_blank" title="Facebook"
                                                    class="text-color-dark text-color-hover-primary text-3 anim-hover-translate-top-5px transition-2ms"><i
                                                        class="fab fa-facebook-f text-3 p-relative top-1"></i></a>
                                            </li>
                                            <li class="nav-item py-2 d-none d-lg-inline-flex">
                                                <a href="http://www.twitter.com/" target="_blank" title="Twitter"
                                                    class="text-color-dark text-color-hover-primary text-3 anim-hover-translate-top-5px transition-2ms"><i
                                                        class="fab fa-x-twitter text-3 p-relative top-1"></i></a>
                                            </li>
                                            <li class="nav-item py-2 d-none d-lg-inline-flex">
                                                <a href="http://www.instagram.com/" target="_blank" title="Instagram"
                                                    class="text-color-dark text-color-hover-primary text-3 anim-hover-translate-top-5px transition-2ms"><i
                                                        class="fab fa-instagram text-3 p-relative top-1"></i></a>
                                            </li>
                                            <li class="nav-item py-2 pe-0 d-none d-lg-inline-flex">
                                                <a href="http://www.linkedin.com/" target="_blank" title="Linkedin"
                                                    class="text-color-dark text-color-hover-primary text-3 anim-hover-translate-top-5px transition-2ms"><i
                                                        class="fab fa-linkedin-in text-3 p-relative top-1"></i></a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="header-container header-container-height-sm container p-static">
                    <div class="header-row">
                        <div class="header-column">
                            <div class="header-row">
                                <div class="header-logo">
                                    <a href="index.html">
                                        <img alt="Porto" width="123" height="32"
                                            src="/assets/img/demos/business-consulting-4/logo.png">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="header-column justify-content-end">
                            <div class="header-row">
                                <div class="header-nav header-nav-links">
                                    <div
                                        class="header-nav-main header-nav-main-square header-nav-main-dropdown-no-borders header-nav-main-dropdown-border-radius header-nav-main-text-capitalize header-nav-main-text-size-4 header-nav-main-arrows header-nav-main-full-width-mega-menu header-nav-main-mega-menu-bg-hover header-nav-main-effect-2">
                                        <nav class="collapse">
                                            <ul class="nav nav-pills" id="mainNav">
                                                <li class="dropdown">
                                                    <a href="demo-business-consulting-4.html" class="nav-link active">
                                                        Home
                                                    </a>
                                                </li>
                                                <li class="dropdown">
                                                    <a class="nav-link dropdown-toggle"
                                                        href="demo-business-consulting-4-services.html">
                                                        Tentang Kami
                                                    </a>
                                                    <ul class="dropdown-menu">
                                                        <li>
                                                            <a href="demo-business-consulting-4-services-detail.html"
                                                                class="dropdown-item">Profil Organisasi</a>
                                                        </li>
                                                        <li>
                                                            <a href="demo-business-consulting-4-services-detail.html"
                                                                class="dropdown-item">Visi Misi</a>
                                                        </li>
                                                        <li>
                                                            <a href="demo-business-consulting-4-services-detail.html"
                                                                class="dropdown-item">Tugas & Fungsi</a>
                                                        </li>
                                                        <li>
                                                            <a href="demo-business-consulting-4-services-detail.html"
                                                                class="dropdown-item">Struktur Organisasi</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="dropdown">
                                                    <a class="nav-link dropdown-toggle"
                                                        href="demo-business-consulting-4-services.html">
                                                        Informasi
                                                    </a>
                                                    <ul class="dropdown-menu">
                                                        <li>
                                                            <a href="demo-business-consulting-4-services-detail.html"
                                                                class="dropdown-item">Berita</a>
                                                        </li>
                                                        <li>
                                                            <a href="demo-business-consulting-4-services-detail.html"
                                                                class="dropdown-item">Infografis</a>
                                                        </li>
                                                        <li>
                                                            <a href="demo-business-consulting-4-services-detail.html"
                                                                class="dropdown-item">Publikasi</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="dropdown">
                                                    <a class="nav-link dropdown-toggle"
                                                        href="demo-business-consulting-4-services.html">
                                                        Layanan
                                                    </a>
                                                    <ul class="dropdown-menu">
                                                        <li>
                                                            <a href="demo-business-consulting-4-services-detail.html"
                                                                class="dropdown-item">Layanan SKT</a>
                                                        </li>
                                                        <li>
                                                            <a href="demo-business-consulting-4-services-detail.html"
                                                                class="dropdown-item">Layanan SKL</a>
                                                        </li>
                                                        <li>
                                                            <a href="https://lapor.go.id" class="dropdown-item">Aduan
                                                                Publik</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </nav>
                                    </div>
                                    <a href="demo-business-consulting-4-contact-us.html"
                                        class="btn btn-modern btn-primary btn-outline btn-arrow-effect-1 text-capitalize text-2-5 ms-3 me-2 d-block d-md-none d-xl-block anim-hover-translate-right-5px transition-2ms">Kontak
                                        <i class="fas fa-arrow-right ms-2"></i></a>
                                    <button class="btn header-btn-collapse-nav" data-bs-toggle="collapse"
                                        data-bs-target=".header-nav-main nav">
                                        <i class="fas fa-bars"></i>
                                    </button>
                                </div>
                                <div class="header-nav-features header-nav-features-no-border ps-2 order-1 order-lg-2">
                                    <div class="header-nav-feature header-nav-features-search d-inline-flex">
                                        <a href="#" class="header-nav-features-toggle text-decoration-none"
                                            data-focus="headerSearch" aria-label="Search"><i
                                                class="fas fa-search header-nav-top-icon text-3"></i></a>
                                        <div class="header-nav-features-dropdown" id="headerTopSearchDropdown">
                                            <form role="search" action="page-search-results.html" method="get">
                                                <div class="simple-search input-group">
                                                    <input class="form-control text-1" id="headerSearch" name="q"
                                                        type="search" value="" placeholder="Search...">
                                                    <button class="btn" type="submit" aria-label="Search">
                                                        <i class="fas fa-search header-nav-top-icon"></i>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <div role="main" class="main">

            <section class="section border-0 m-0 bg-color-quaternary p-relative">
                <div class="container">
                    <div class="row custom-hero-row">

                        <div class="col">
                            <div class="row pt-5 mt-5 mb-5 pb-5">
                                <div class="col-12 col-lg-6 p-relative pt-5 mt-5">
                                    <div class="divider divider-small divider-small-lg appear-animation"
                                        data-appear-animation="fadeInUpShorter" data-appear-animation-delay="0">
                                        <hr class="bg-primary border-radius">
                                    </div>
                                    <div class="overflow-hidden mb-1">
                                        <h2 class="font-weight-semi-bold text-color-grey text-uppercase positive-ls-3 text-4-5 line-height-2 line-height-sm-7 mb-0 appear-animation"
                                            data-appear-animation="maskUp" data-appear-animation-delay="100">A leading
                                            consulting firm</h2>
                                    </div>
                                    <h1 class="text-color-dark font-weight-bold text-9 pb-2 mb-4 appear-animation"
                                        data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">
                                        Digital, business and technology<br>consulting for growth.</h1>
                                    <div class="d-block appear-animation" data-appear-animation="fadeInUpShorter"
                                        data-appear-animation-delay="300">
                                        <a href="#start" data-hash data-hash-offset="0" data-hash-offset-lg="100"
                                            class="btn btn-modern btn-primary btn-arrow-effect-1 text-capitalize text-2-5 px-5 py-3 anim-hover-translate-top-5px transition-2ms">Learn
                                            More <i class="fas fa-arrow-right ms-2"></i></a>
                                    </div>
                                    <div class="pt-5 appear-animation" data-appear-animation="fadeInUpShorter"
                                        data-appear-animation-delay="400">
                                        <span class="d-inline-block anim-hover-translate-bottom-5px transition-2ms">
                                            <a href="#start" data-hash data-hash-offset="0" data-hash-offset-lg="100"
                                                class="btn btn-default text-color-primary border-color-primary bg-transparent rotate-r-90 btn-circle border-width-2 btn-lg"><i
                                                    class="fas fa-arrow-right"></i></a>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 p-relative text-end">

                                    <div class="appear-animation custom-element-wrapper custom-element-6"
                                        data-appear-animation="expandIn" data-appear-animation-delay="500">
                                        <div class="bg-color-primary particle particle-dots w-100 h-100 opacity-3">
                                        </div>
                                    </div>

                                    <div class="appear-animation custom-element-wrapper p-relative custom-element-5"
                                        data-appear-animation="expandIn" data-appear-animation-delay="0">
                                        <div class="w-100 h-100">
                                            <div class="custom-element rotate-r-45"></div>
                                        </div>
                                    </div>

                                    <img class="appear-animation img-fluid custom-element-wrapper custom-element-8"
                                        data-appear-animation="fadeIn" data-appear-animation-delay="900"
                                        src="img/demos/business-consulting-4/generic/generic-1.png" alt="">

                                </div>
                            </div>
                            <div class="row align-items-end justify-content-end pt-5">
                                <div class="col-lg-9 text-end pt-5">
                                    <div class="appear-animation" data-appear-animation="fadeIn"
                                        data-appear-animation-delay="800">
                                        <div class="owl-carousel owl-theme stage-margin rounded-nav nav-dark nav-icon-1 nav-size-md nav-position-1"
                                            data-plugin-options="{'responsive': {'0': {'items': 1}, '479': {'items': 1}, '768': {'items': 2}, '979': {'items': 2}, '1199': {'items': 2}}, 'margin': 10, 'loop': true, 'nav': true, 'dots': false, 'stagePadding': 40}">
                                            <div
                                                class="overlay overlay-color-primary overlay-show overlay-op-8 rounded overflow-hidden">
                                                <img alt="" class="img-fluid rounded"
                                                    src="/assets/img/demos/business-consulting-4/generic/generic-2.jpg">
                                                <a href="#"
                                                    class="p-absolute z-index-2 top-0 left-0 w-100 h-100 anim-hover-translate-top-5px transition-2ms">
                                                    <span
                                                        class="p-absolute left-0 bottom-0 text-color-light text-start ms-4 mb-3 ps-2 pb-1">
                                                        <strong class="text-5 negative-ls-05 font-weight-bold">Why
                                                            Choose Us</strong>
                                                        <p
                                                            class="font-weight-medium text-color-light opacity-7 p-relative bottom-4 mb-0">
                                                            Lorem ipsum dolor sit amet...</p>
                                                    </span>
                                                </a>
                                            </div>
                                            <div
                                                class="overlay overlay-color-dark overlay-show overlay-op-9 rounded overflow-hidden">
                                                <img alt="" class="img-fluid rounded"
                                                    src="/assets/img/demos/business-consulting-4/generic/generic-3.jpg">
                                                <a href="#"
                                                    class="p-absolute z-index-2 top-0 left-0 w-100 h-100 anim-hover-translate-top-5px transition-2ms">
                                                    <span
                                                        class="p-absolute left-0 bottom-0 text-color-light text-start ms-4 mb-3 ps-2 pb-1">
                                                        <strong
                                                            class="text-5 negative-ls-05 font-weight-bold">Consulting
                                                            for Growth</strong>
                                                        <p
                                                            class="font-weight-medium text-color-light opacity-7 p-relative bottom-4 mb-0">
                                                            Lorem ipsum dolor sit amet...</p>
                                                    </span>
                                                </a>
                                            </div>
                                            <div
                                                class="overlay overlay-color-primary overlay-show overlay-op-8 rounded overflow-hidden">
                                                <img alt="" class="img-fluid rounded"
                                                    src="/assets/img/demos/business-consulting-4/generic/generic-4.jpg">
                                                <a href="#"
                                                    class="p-absolute z-index-2 top-0 left-0 w-100 h-100 anim-hover-translate-top-5px transition-2ms">
                                                    <span
                                                        class="p-absolute left-0 bottom-0 text-color-light text-start ms-4 mb-3 ps-2 pb-1">
                                                        <strong class="text-5 negative-ls-05 font-weight-bold">Why
                                                            Choose Us</strong>
                                                        <p
                                                            class="font-weight-medium text-color-light opacity-7 p-relative bottom-4 mb-0">
                                                            Lorem ipsum dolor sit amet...</p>
                                                    </span>
                                                </a>
                                            </div>
                                            <div
                                                class="overlay overlay-color-dark overlay-show overlay-op-9 rounded overflow-hidden">
                                                <img alt="" class="img-fluid rounded"
                                                    src="/assets/img/demos/business-consulting-4/generic/generic-5.jpg">
                                                <a href="#"
                                                    class="p-absolute z-index-2 top-0 left-0 w-100 h-100 anim-hover-translate-top-5px transition-2ms">
                                                    <span
                                                        class="p-absolute left-0 bottom-0 text-color-light text-start ms-4 mb-3 ps-2 pb-1">
                                                        <strong
                                                            class="text-5 negative-ls-05 font-weight-bold">Consulting
                                                            for Growth</strong>
                                                        <p
                                                            class="font-weight-medium text-color-light opacity-7 p-relative bottom-4 mb-0">
                                                            Lorem ipsum dolor sit amet...</p>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="appear-animation custom-element-wrapper custom-element-1" data-appear-animation="expandIn"
                    data-appear-animation-delay="200">
                    <div class="w-100 h-100" data-plugin-float-element
                        data-plugin-options="{'startPos': 'bottom', 'speed': 2.1, 'transition': true, 'transitionDuration': 500}">
                        <div class="custom-element rotate-r-45"></div>
                    </div>
                </div>

                <div class="appear-animation custom-element-wrapper custom-element-2" data-appear-animation="expandIn"
                    data-appear-animation-delay="200">
                    <div class="w-100 h-100" data-plugin-float-element
                        data-plugin-options="{'startPos': 'bottom', 'speed': 2.2, 'transition': true, 'transitionDuration': 500}">
                        <div class="custom-element rotate-r-45"></div>
                    </div>
                </div>

                <div class="appear-animation custom-element-wrapper custom-element-3" data-appear-animation="expandIn"
                    data-appear-animation-delay="200">
                    <div class="w-100 h-100" data-plugin-float-element
                        data-plugin-options="{'startPos': 'bottom', 'speed': 2.3, 'transition': true, 'transitionDuration': 500}">
                        <div class="custom-element rotate-r-45"></div>
                    </div>
                </div>

                <div class="appear-animation custom-element-wrapper custom-element-4" data-appear-animation="expandIn"
                    data-appear-animation-delay="200">
                    <div class="w-100 h-100" data-plugin-float-element
                        data-plugin-options="{'startPos': 'bottom', 'speed': 2.4, 'transition': true, 'transitionDuration': 500}">
                        <div class="custom-element rotate-r-45"></div>
                    </div>
                </div>

            </section>

            <section class="section border-0 bg-transparent m-0" id="start">
                <div class="container py-5 mb-3">
                    <div class="row">
                        <div class="col text-center">

                            <div class="divider divider-small divider-small-lg mt-0 text-center appear-animation"
                                data-appear-animation="fadeInUpShorter" data-appear-animation-delay="0">
                                <hr class="bg-primary border-radius m-auto">
                            </div>
                            <div class="overflow-hidden mb-1">
                                <h3 class="font-weight-semi-bold text-color-grey text-uppercase positive-ls-3 text-4 line-height-2 line-height-sm-7 mb-0 appear-animation"
                                    data-appear-animation="maskUp" data-appear-animation-delay="100">Our Mission</h3>
                            </div>
                            <h2 class="text-color-dark font-weight-bold text-8 pb-2 mb-4 appear-animation"
                                data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">We are
                                committed to providing our clients the best<br>strategic guidance available</h2>

                        </div>
                    </div>
                    <div class="row pt-4 pb-5">
                        <div class="col-lg-6 text-center p-relative pt-5">

                            <div class="appear-animation custom-element-wrapper custom-element-9"
                                data-appear-animation="expandIn" data-appear-animation-delay="1000">
                                <div class="bg-color-primary particle particle-dots w-100 h-100 opacity-3"></div>
                            </div>

                            <div class="appear-animation custom-element-wrapper custom-element-10"
                                data-appear-animation="expandIn" data-appear-animation-delay="1200">
                                <div class="bg-color-primary particle particle-dots w-100 h-100 opacity-3"></div>
                            </div>

                            <div class="appear-animation custom-element-wrapper custom-element-11 p-relative rotate-r-45"
                                data-appear-animation="fadeIn" data-appear-animation-delay="300">
                                <img class="img-fluid" src="img/demos/business-consulting-4/generic/generic-6.jpg"
                                    alt="">
                            </div>

                        </div>
                        <div class="col-lg-6 pt-5 mt-5 pt-lg-0 mt-lg-0">
                            <div class="appear-animation" data-appear-animation="fadeIn"
                                data-appear-animation-delay="300">
                                <p class="font-weight-medium text-4-5 line-height-5">Cras a elit sit amet leo accumsan
                                    volutpat. Suspendisse hendrerit vehicula leo, vel efficitur felis ultrices non.
                                    Integer aliquet ullamcorper dolor, quis sollicitudin.</p>
                                <p class="text-3-5">Cras a elit sit amet leo accumsan volutpat. Suspendisse hendrerit
                                    vehicula leo, vel efficitur felis ultrices non. Integer aliquet.</p>

                                <ul class="list list-icons list-icons-style-2 list-icons-lg">
                                    <li class="line-height-9 text-3-5 mb-1">
                                        <i class="fas fa-check border-width-2 text-3"></i>Amet orci quis arcu vestibulum
                                        vestibulum.
                                    </li>
                                    <li class="line-height-9 text-3-5 mb-1">
                                        <i class="fas fa-check border-width-2 text-3"></i>Quis arcu vestibulum
                                        vestibulum.
                                    </li>
                                    <li class="line-height-9 text-3-5 mb-1">
                                        <i class="fas fa-check border-width-2 text-3"></i>Sit amet orci quis arcu.
                                    </li>
                                </ul>
                            </div>

                            <div class="d-block pt-4 appear-animation" data-appear-animation="fadeInUpShorter"
                                data-appear-animation-delay="300">
                                <a href="demo-business-consulting-4-about-us.html"
                                    class="btn btn-modern btn-primary btn-arrow-effect-1 text-capitalize text-2-5 px-5 py-3 anim-hover-translate-top-5px transition-2ms">Learn
                                    More <i class="fas fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="section border-0 bg-quaternary m-0">
                <div class="container py-5">
                    <div class="row justify-content-center">
                        <div class="col col-lg-9 text-center">

                            <div class="divider divider-small divider-small-lg mt-0 text-center appear-animation"
                                data-appear-animation="fadeInUpShorter" data-appear-animation-delay="0">
                                <hr class="bg-primary border-radius m-auto">
                            </div>
                            <div class="overflow-hidden mb-1">
                                <h3 class="font-weight-semi-bold text-color-grey text-uppercase positive-ls-3 text-4 line-height-2 line-height-sm-7 mb-0 appear-animation"
                                    data-appear-animation="maskUp" data-appear-animation-delay="100">How We Can Help
                                </h3>
                            </div>
                            <h2 class="text-color-dark font-weight-bold text-8 pb-4 mb-0 appear-animation"
                                data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">Our Amazing
                                Services</h2>

                            <p class="font-weight-medium text-4-5 line-height-5 appear-animation"
                                data-appear-animation="fadeInUpShorter" data-appear-animation-delay="400">Cras a elit
                                sit amet leo accumsan volutpat. Suspendisse hendrerit vehicula leo, vel efficitur felis
                                ultrices non.</p>

                        </div>
                    </div>

                    <div class="row py-5 appear-animation" data-appear-animation="fadeIn"
                        data-appear-animation-delay="300">
                        <div class="col-md-4 mb-4 mb-md-0">
                            <div
                                class="card card-border card-border-top card-border-hover bg-color-light border-0 box-shadow-6 box-shadow-hover anim-hover-translate-top-10px transition-3ms anim-hover-inner-wrapper">
                                <div class="card-body p-relative zindex-1 p-5 text-center">
                                    <div class="anim-hover-inner-translate-top-20px transition-3ms">
                                        <img width="72" height="73"
                                            src="/assets/img/demos/business-consulting-4/icons/icon-1.svg" alt=""
                                            data-icon
                                            data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-primary'}" />
                                        <h4 class="card-title mt-4 mb-2 text-5 font-weight-bold">Strategic Planning</h4>
                                        <p class="card-text text-3-5">Lorem ipsum dolor sit amet, consectetur elit.</p>
                                    </div>
                                    <div
                                        class="w-100 text-center p-absolute opacity-0 bottom-30 left-0 transformY-p100 anim-hover-inner-opacity-10 anim-hover-inner-translate-top-0px transition-4ms">
                                        <a href="demo-business-consulting-4-services-detail.html"
                                            class="read-more text-color-primary font-weight-semibold mt-2 text-2">Learn
                                            More <i class="fas fa-angle-right position-relative top-1 ms-1"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4 mb-md-0">
                            <div
                                class="card card-border card-border-top card-border-hover bg-color-light border-0 box-shadow-6 box-shadow-hover anim-hover-translate-top-10px transition-3ms anim-hover-inner-wrapper">
                                <div class="card-body p-relative zindex-1 p-5 text-center">
                                    <div class="anim-hover-inner-translate-top-20px transition-3ms">
                                        <img width="72" height="73"
                                            src="/assets/img/demos/business-consulting-4/icons/icon-2.svg" alt=""
                                            data-icon
                                            data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-primary'}" />
                                        <h4 class="card-title mt-4 mb-2 text-5 font-weight-bold">Financial Clean-Up</h4>
                                        <p class="card-text text-3-5">Lorem ipsum dolor sit amet, consectetur elit.</p>
                                    </div>
                                    <div
                                        class="w-100 text-center p-absolute opacity-0 bottom-30 left-0 transformY-p100 anim-hover-inner-opacity-10 anim-hover-inner-translate-top-0px transition-4ms">
                                        <a href="demo-business-consulting-4-services-detail.html"
                                            class="read-more text-color-primary font-weight-semibold mt-2 text-2">Learn
                                            More <i class="fas fa-angle-right position-relative top-1 ms-1"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div
                                class="card card-border card-border-top card-border-hover bg-color-light border-0 box-shadow-6 box-shadow-hover anim-hover-translate-top-10px transition-3ms anim-hover-inner-wrapper">
                                <div class="card-body p-relative zindex-1 p-5 text-center">
                                    <div class="anim-hover-inner-translate-top-20px transition-3ms">
                                        <img width="72" height="73"
                                            src="/assets/img/demos/business-consulting-4/icons/icon-3.svg" alt=""
                                            data-icon
                                            data-plugin-options="{'onlySVG': true, 'extraClass': 'svg-fill-color-primary'}" />
                                        <h4 class="card-title mt-4 mb-2 text-5 font-weight-bold">Cash Flow Planning</h4>
                                        <p class="card-text text-3-5">Lorem ipsum dolor sit amet, consectetur elit.</p>
                                    </div>
                                    <div
                                        class="w-100 text-center p-absolute opacity-0 bottom-30 left-0 transformY-p100 anim-hover-inner-opacity-10 anim-hover-inner-translate-top-0px transition-4ms">
                                        <a href="demo-business-consulting-4-services-detail.html"
                                            class="read-more text-color-primary font-weight-semibold mt-2 text-2">Learn
                                            More <i class="fas fa-angle-right position-relative top-1 ms-1"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row justify-content-center">
                        <div class="col col-lg-9 text-center">

                            <div class="d-block pt-4 appear-animation" data-appear-animation="fadeInUpShorter"
                                data-appear-animation-delay="300">
                                <a href="demo-business-consulting-4-services.html"
                                    class="btn btn-modern btn-primary btn-arrow-effect-1 text-capitalize text-2-5 px-5 py-3 anim-hover-translate-top-5px transition-2ms">Learn
                                    More <i class="fas fa-arrow-right ms-2"></i></a>
                            </div>

                        </div>
                    </div>
                </div>
            </section>
			<section class="section section-no-border bg-color-light m-0">
					<div class="container">
						<div class="row">
							<div class="col">
								<div id="galleryAjaxBox" class="ajax-box mb-4">

									<div class="bounce-loader">
										<div class="bounce1"></div>
										<div class="bounce2"></div>
										<div class="bounce3"></div>
									</div>

									<div class="ajax-box-content" id="galleryAjaxBoxContent"></div>

								</div>
							</div>
						</div>
						<div class="row" data-plugin-masonry="" data-plugin-options="{'itemSelector': '.col-lg-4'}" style="position: relative; height: 746.766px;">
							<div class="col-lg-4" style="position: absolute; left: 0px; top: 0px;">
								<span class="thumb-info custom-thumb-info-4">
									<a data-href="ajax/demo-church-gallery-ajax-on-page-1.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
										<span class="thumb-info-wrapper active">
											<img src="img/demos/church/gallery/gallery-1.jpg" alt="" class="img-fluid">
										</span>
									</a>
									<span class="thumb-info-caption custom-box-shadow">
										<span class="thumb-info-caption-text">
											<h2 class="font-weight-bold text-5 text-center">
												<a data-href="ajax/demo-church-gallery-ajax-on-page-1.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
													Baptism
												</a>
											</h2>
										</span>
									</span>
								</span>
							</div>
							<div class="col-lg-4" style="position: absolute; left: 319.984px; top: 0px;">
								<span class="thumb-info custom-thumb-info-4">
									<a data-href="ajax/demo-church-gallery-ajax-on-page-2.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
										<span class="thumb-info-wrapper">
											<img src="img/demos/church/gallery/gallery-2.jpg" alt="" class="img-fluid">
										</span>
									</a>
									<span class="thumb-info-caption custom-box-shadow">
										<span class="thumb-info-caption-text">
											<h2 class="font-weight-bold text-5 text-center">
												<a data-href="ajax/demo-church-gallery-ajax-on-page-2.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
													Wedding
												</a>
											</h2>
										</span>
									</span>
								</span>
							</div>
							<div class="col-lg-4" style="position: absolute; left: 639.968px; top: 0px;">
								<span class="thumb-info custom-thumb-info-4">
									<a data-href="ajax/demo-church-gallery-ajax-on-page-3.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
										<span class="thumb-info-wrapper">
											<img src="img/demos/church/gallery/gallery-3.jpg" alt="" class="img-fluid">
										</span>
									</a>
									<span class="thumb-info-caption custom-box-shadow">
										<span class="thumb-info-caption-text">
											<h2 class="font-weight-bold text-5 text-center">
												<a data-href="ajax/demo-church-gallery-ajax-on-page-3.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
													Church Community
												</a>
											</h2>
										</span>
									</span>
								</span>
							</div>
							<div class="col-lg-4" style="position: absolute; left: 319.984px; top: 247.812px;">
								<span class="thumb-info custom-thumb-info-4">
									<a data-href="ajax/demo-church-gallery-ajax-on-page-2.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
										<span class="thumb-info-wrapper">
											<img src="img/demos/church/gallery/gallery-4.jpg" alt="" class="img-fluid">
										</span>
									</a>
									<span class="thumb-info-caption custom-box-shadow">
										<span class="thumb-info-caption-text">
											<h2 class="font-weight-bold text-5 text-center">
												<a data-href="ajax/demo-church-gallery-ajax-on-page-2.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
													Wedding
												</a>
											</h2>
										</span>
									</span>
								</span>
							</div>
							<div class="col-lg-4" style="position: absolute; left: 0px; top: 248.922px;">
								<span class="thumb-info custom-thumb-info-4">
									<a data-href="ajax/demo-church-gallery-ajax-on-page-3.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
										<span class="thumb-info-wrapper">
											<img src="img/demos/church/gallery/gallery-5.jpg" alt="" class="img-fluid">
										</span>
									</a>
									<span class="thumb-info-caption custom-box-shadow">
										<span class="thumb-info-caption-text">
											<h2 class="font-weight-bold text-5 text-center">
												<a data-href="ajax/demo-church-gallery-ajax-on-page-3.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
													Church Community
												</a>
											</h2>
										</span>
									</span>
								</span>
							</div>
							<div class="col-lg-4" style="position: absolute; left: 639.968px; top: 248.922px;">
								<span class="thumb-info custom-thumb-info-4">
									<a data-href="ajax/demo-church-gallery-ajax-on-page-1.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
										<span class="thumb-info-wrapper">
											<img src="img/demos/church/gallery/gallery-6.jpg" alt="" class="img-fluid">
										</span>
									</a>
									<span class="thumb-info-caption custom-box-shadow">
										<span class="thumb-info-caption-text">
											<h2 class="font-weight-bold text-5 text-center">
												<a data-href="ajax/demo-church-gallery-ajax-on-page-1.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
													Baptism
												</a>
											</h2>
										</span>
									</span>
								</span>
							</div>
							<div class="col-lg-4" style="position: absolute; left: 319.984px; top: 496.734px;">
								<span class="thumb-info custom-thumb-info-4">
									<a data-href="ajax/demo-church-gallery-ajax-on-page-1.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
										<span class="thumb-info-wrapper">
											<img src="img/demos/church/gallery/gallery-7.jpg" alt="" class="img-fluid">
										</span>
									</a>
									<span class="thumb-info-caption custom-box-shadow">
										<span class="thumb-info-caption-text">
											<h2 class="font-weight-bold text-5 text-center">
												<a data-href="ajax/demo-church-gallery-ajax-on-page-1.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
													Baptism
												</a>
											</h2>
										</span>
									</span>
								</span>
							</div>
							<div class="col-lg-4" style="position: absolute; left: 639.968px; top: 497.469px;">
								<span class="thumb-info custom-thumb-info-4">
									<a data-href="ajax/demo-church-gallery-ajax-on-page-2.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
										<span class="thumb-info-wrapper">
											<img src="img/demos/church/gallery/gallery-8.jpg" alt="" class="img-fluid">
										</span>
									</a>
									<span class="thumb-info-caption custom-box-shadow">
										<span class="thumb-info-caption-text">
											<h2 class="font-weight-bold text-5 text-center">
												<a data-href="ajax/demo-church-gallery-ajax-on-page-2.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
													Wedding
												</a>
											</h2>
										</span>
									</span>
								</span>
							</div>
							<div class="col-lg-4" style="position: absolute; left: 0px; top: 497.844px;">
								<span class="thumb-info custom-thumb-info-4">
									<a data-href="ajax/demo-church-gallery-ajax-on-page-3.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
										<span class="thumb-info-wrapper">
											<img src="img/demos/church/gallery/gallery-9.jpg" alt="" class="img-fluid">
										</span>
									</a>
									<span class="thumb-info-caption custom-box-shadow">
										<span class="thumb-info-caption-text">
											<h2 class="font-weight-bold text-5 text-center">
												<a data-href="ajax/demo-church-gallery-ajax-on-page-3.html" class="text-decoration-none custom-secondary-font text-color-dark" data-ajax-on-page="">
													Church Community
												</a>
											</h2>
										</span>
									</span>
								</span>
							</div>
						</div>
					</div>
				</section>
            


            <section class="section border-0 bg-quaternary m-0">
                <div class="container py-5">
                    <div class="row justify-content-center">
                        <div class="col col-lg-9 text-center">

                            <div class="divider divider-small divider-small-lg mt-0 text-center appear-animation"
                                data-appear-animation="fadeInUpShorter" data-appear-animation-delay="0">
                                <hr class="bg-primary border-radius m-auto">
                            </div>
                            <div class="overflow-hidden mb-1">
                                <h3 class="font-weight-semi-bold text-color-grey text-uppercase positive-ls-3 text-4 line-height-2 line-height-sm-7 mb-0 appear-animation"
                                    data-appear-animation="maskUp" data-appear-animation-delay="100">What They Say About
                                    Us</h3>
                            </div>
                            <h2 class="text-color-dark font-weight-bold text-8 pb-4 mb-0 appear-animation"
                                data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">Testimonials
                            </h2>

                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col appear-animation" data-appear-animation="fadeIn"
                            data-appear-animation-delay="300">

                            <div class="owl-carousel owl-theme stage-margin rounded-nav nav-dark nav-icon-1 nav-size-md mb-0"
                                data-plugin-options="{'responsive': {'0': {'items': 1}, '479': {'items': 1}, '768': {'items': 2}, '979': {'items': 2}, '1199': {'items': 2}}, 'margin': 0, 'loop': true, 'nav': true, 'dots': false, 'stagePadding': 40}">
                                <div class="mx-3">
                                    <div class="testimonial testimonial-style-3 testimonial-style-3-light">
                                        <blockquote class="p-3 before-d-none">
                                            <p class="font-weight-medium text-4 line-height-5 p-3 m-0">Lorem ipsum dolor
                                                sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in
                                                consequat.</p>
                                        </blockquote>
                                        <div class="testimonial-arrow-down p-relative z-index-1"></div>
                                        <div class="testimonial-author">
                                            <div class="testimonial-author-thumbnail">
                                                <img src="/assets/img/clients/client-1.jpg"
                                                    class="img-fluid rounded-circle" alt="">
                                            </div>
                                            <p><strong class="font-weight-extra-bold">John Smith</strong><span>CEO &
                                                    Founder - Okler</span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="mx-3">
                                    <div class="testimonial testimonial-style-3 testimonial-style-3-light">
                                        <blockquote class="p-3 before-d-none">
                                            <p class="font-weight-medium text-4 line-height-5 p-3 m-0">Lorem ipsum dolor
                                                sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in
                                                consequat.</p>
                                        </blockquote>
                                        <div class="testimonial-arrow-down p-relative z-index-1"></div>
                                        <div class="testimonial-author">
                                            <div class="testimonial-author-thumbnail">
                                                <img src="/assets/img/clients/client-1.jpg"
                                                    class="img-fluid rounded-circle" alt="">
                                            </div>
                                            <p><strong class="font-weight-extra-bold">John Smith</strong><span>CEO &
                                                    Founder - Okler</span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="mx-3">
                                    <div class="testimonial testimonial-style-3 testimonial-style-3-light">
                                        <blockquote class="p-3 before-d-none">
                                            <p class="font-weight-medium text-4 line-height-5 p-3 m-0">Lorem ipsum dolor
                                                sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in
                                                consequat.</p>
                                        </blockquote>
                                        <div class="testimonial-arrow-down p-relative z-index-1"></div>
                                        <div class="testimonial-author">
                                            <div class="testimonial-author-thumbnail">
                                                <img src="/assets/img/clients/client-1.jpg"
                                                    class="img-fluid rounded-circle" alt="">
                                            </div>
                                            <p><strong class="font-weight-extra-bold">John Smith</strong><span>CEO &
                                                    Founder - Okler</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </section>
            <section class="section border-0 bg-light m-0">
                <div class="container py-5">
                    <div class="row align-items-center text-center">
                        <div class="col-sm-4 col-lg-2 mb-5 mb-lg-0">
                            <img src="/assets/img/logos/logo-8.png" alt="" class="img-fluid" style="max-width: 90px;">
                        </div>
                        <div class="col-sm-4 col-lg-2 mb-5 mb-lg-0">
                            <img src="/assets/img/logos/logo-9.png" alt="" class="img-fluid" style="max-width: 140px;">
                        </div>
                        <div class="col-sm-4 col-lg-2 mb-5 mb-lg-0">
                            <img src="/assets/img/logos/logo-10.png" alt="" class="img-fluid" style="max-width: 140px;">
                        </div>
                        <div class="col-sm-4 col-lg-2 mb-5 mb-sm-0">
                            <img src="/assets/img/logos/logo-11.png" alt="" class="img-fluid" style="max-width: 140px;">
                        </div>
                        <div class="col-sm-4 col-lg-2 mb-5 mb-sm-0">
                            <img src="/assets/img/logos/logo-12.png" alt="" class="img-fluid" style="max-width: 100px;">
                        </div>
                        <div class="col-sm-4 col-lg-2">
                            <img src="/assets/img/logos/logo-13.png" alt="" class="img-fluid" style="max-width: 100px;">
                        </div>
                    </div>
                </div>
            </section>

            <section class="section border-0 bg-quaternary m-0">
                <div class="container py-5">
                    <div class="row justify-content-center">
                        <div class="col col-lg-9 text-center">

                            <div class="divider divider-small divider-small-lg mt-0 text-center appear-animation"
                                data-appear-animation="fadeInUpShorter" data-appear-animation-delay="0">
                                <hr class="bg-primary border-radius m-auto">
                            </div>
                            <div class="overflow-hidden mb-1">
                                <h3 class="font-weight-semi-bold text-color-grey text-uppercase positive-ls-3 text-4 line-height-2 line-height-sm-7 mb-0 appear-animation"
                                    data-appear-animation="maskUp" data-appear-animation-delay="100">What Is Happening
                                </h3>
                            </div>
                            <h2 class="text-color-dark font-weight-bold text-8 pb-4 mb-0 appear-animation"
                                data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">Latest News
                            </h2>

                        </div>
                    </div>

                    <div class="row justify-content-center appear-animation" data-appear-animation="fadeIn"
                        data-appear-animation-delay="300">
                        <div class="col-9 col-md-6 col-lg-4 mb-4 mb-lg-0">
                            <a href="demo-business-consulting-4-blog-post.html" class="text-decoration-none">
                                <div class="card border-0 bg-transparent">
                                    <div class="card-img-top position-relative overlay overflow-hidden border-radius">
                                        <div
                                            class="position-absolute bottom-10 right-0 d-flex justify-content-end w-100 py-3 px-4 z-index-3">
                                            <span
                                                class="text-center bg-primary text-color-light border-radius font-weight-semibold line-height-2 px-3 py-2">
                                                <span class="position-relative text-6 z-index-2">
                                                    18
                                                    <span class="d-block text-0 positive-ls-2 px-1">FEB</span>
                                                </span>
                                            </span>
                                        </div>
                                        <img src="/assets/img/demos/business-consulting-4/blog/post-thumb-1.jpg"
                                            class="img-fluid border-radius" alt="Lorem Ipsum Dolor" />
                                    </div>
                                    <div class="card-body py-4 px-0">
                                        <span
                                            class="d-block text-color-grey font-weight-semibold positive-ls-2 text-2">BY
                                            ADMIN</span>
                                        <h4 class="font-weight-bold text-5 text-color-hover-primary mb-2">Lorem ipsum
                                            dolor sit a met, consectetur</h4>
                                        <a href="demo-business-consulting-4-blog-post.html"
                                            class="read-more text-color-primary font-weight-semibold mt-0 text-2">Read
                                            More <i class="fas fa-angle-right position-relative top-1 ms-1"></i></a>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-9 col-md-6 col-lg-4 mb-4 mb-lg-0">
                            <a href="demo-business-consulting-4-blog-post.html" class="text-decoration-none">
                                <div class="card border-0 bg-transparent">
                                    <div class="card-img-top position-relative overlay overflow-hidden border-radius">
                                        <div
                                            class="position-absolute bottom-10 right-0 d-flex justify-content-end w-100 py-3 px-4 z-index-3">
                                            <span
                                                class="text-center bg-primary text-color-light border-radius font-weight-semibold line-height-2 px-3 py-2">
                                                <span class="position-relative text-6 z-index-2">
                                                    15
                                                    <span class="d-block text-0 positive-ls-2 px-1">FEB</span>
                                                </span>
                                            </span>
                                        </div>
                                        <img src="/assets/img/demos/business-consulting-4/blog/post-thumb-2.jpg"
                                            class="img-fluid border-radius" alt="Lorem Ipsum Dolor" />
                                    </div>
                                    <div class="card-body py-4 px-0">
                                        <span
                                            class="d-block text-color-grey font-weight-semibold positive-ls-2 text-2">BY
                                            ADMIN</span>
                                        <h4 class="font-weight-bold text-5 text-color-hover-primary mb-2">Lorem ipsum
                                            dolor sit a met, consectetur</h4>
                                        <a href="demo-business-consulting-4-blog-post.html"
                                            class="read-more text-color-primary font-weight-semibold mt-0 text-2">Read
                                            More <i class="fas fa-angle-right position-relative top-1 ms-1"></i></a>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-9 col-md-6 col-lg-4">
                            <a href="demo-business-consulting-4-blog-post.html" class="text-decoration-none">
                                <div class="card border-0 bg-transparent">
                                    <div class="card-img-top position-relative overlay overflow-hidden border-radius">
                                        <div
                                            class="position-absolute bottom-10 right-0 d-flex justify-content-end w-100 py-3 px-4 z-index-3">
                                            <span
                                                class="text-center bg-primary text-color-light border-radius font-weight-semibold line-height-2 px-3 py-2">
                                                <span class="position-relative text-6 z-index-2">
                                                    12
                                                    <span class="d-block text-0 positive-ls-2 px-1">FEB</span>
                                                </span>
                                            </span>
                                        </div>
                                        <img src="/assets/img/demos/business-consulting-4/blog/post-thumb-3.jpg"
                                            class="img-fluid border-radius" alt="Lorem Ipsum Dolor" />
                                    </div>
                                    <div class="card-body py-4 px-0">
                                        <span
                                            class="d-block text-color-grey font-weight-semibold positive-ls-2 text-2">BY
                                            ADMIN</span>
                                        <h4 class="font-weight-bold text-5 text-color-hover-primary mb-2">Lorem ipsum
                                            dolor sit a met, consectetur</h4>
                                        <a href="demo-business-consulting-4-blog-post.html"
                                            class="read-more text-color-primary font-weight-semibold mt-0 text-2">Read
                                            More <i class="fas fa-angle-right position-relative top-1 ms-1"></i></a>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>

                </div>
            </section>

        </div>

        <footer id="footer" class="position-relative bg-dark border-top-0">
            <div class="container pt-5 pb-3">
                <div class="row pt-5">
                    <div class="col-lg-4">
                        <a href="demo-business-consulting-4.html" class="text-decoration-none">
                            <img src="/assets/img/demos/business-consulting-4/logo-light.png" width="123" height="32"
                                class="img-fluid mb-4" alt="Porto" />
                        </a>
                        <p class="text-3-5 font-weight-medium pe-lg-2">Lorem ipsum dolor sit amet, consectetur
                            adipiscing elit quisque rutrum pellentesqu. </p>
                        <ul class="list list-unstyled">
                            <li class="d-flex align-items-center mb-4">
                                <i
                                    class="icon icon-envelope text-color-light text-5 font-weight-bold position-relative top-1 me-3-5"></i>
                                <a href="mailto:porto@business-consulting-4.com"
                                    class="d-inline-flex align-items-center text-decoration-none text-color-light text-color-hover-primary font-weight-semibold text-4-5">porto@domain.com</a>
                            </li>
                            <li class="d-flex align-items-center mb-4">
                                <i
                                    class="icon icon-phone text-color-light text-5 font-weight-bold position-relative top-1 me-3-5"></i>
                                <a href="tel:8001234567"
                                    class="d-inline-flex align-items-center text-decoration-none text-color-light text-color-hover-primary font-weight-semibold text-4-5">800-123-4567</a>
                            </li>
                        </ul>
                        <ul class="social-icons social-icons-clean social-icons-medium">
                            <li class="social-icons-facebook">
                                <a href="http://www.facebook.com/" target="_blank" title="Facebook">
                                    <i class="fab fa-facebook-f text-color-light"></i>
                                </a>
                            </li>
                            <li class="social-icons-twitter">
                                <a href="http://www.twitter.com/" target="_blank" title="Twitter">
                                    <i class="fab fa-x-twitter text-color-light"></i>
                                </a>
                            </li>
                            <li class="social-icons-instagram">
                                <a href="http://www.instagram.com/" target="_blank" title="Instagram">
                                    <i class="fab fa-instagram text-color-light"></i>
                                </a>
                            </li>
                            <li class="social-icons-linkedin">
                                <a href="http://www.linkedin.com/" target="_blank" title="Linkedin">
                                    <i class="fab fa-linkedin text-color-light"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-8">

                        <div class="row">
                            <div class="col">
                                <div class="alert alert-success d-none" id="newsletterSuccess">
                                    <strong>Success!</strong> You've been added to our email list.
                                </div>
                                <div class="alert alert-danger d-none" id="newsletterError"></div>
                                <div class="d-flex flex-column flex-lg-row align-items-start align-items-lg-center">
                                    <h4 class="text-color-light ws-nowrap me-3 mb-3 mb-lg-0">Subscribe to Newsletter:
                                    </h4>
                                    <form id="newsletterForm" class="form-style-3 w-100"
                                        action="php/newsletter-subscribe.php" method="POST">
                                        <div class="d-flex">
                                            <input class="form-control bg-color-light border-0 box-shadow-none"
                                                placeholder="Email Address" name="newsletterEmail" id="newsletterEmail"
                                                type="text" />
                                            <button class="btn btn-primary ms-2 btn-px-3 btn-py-2 font-weight-bold"
                                                type="submit">
                                                Go
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-copyright bg-transparent">
                <div class="container">
                    <hr class="bg-color-light opacity-1">
                    <div class="row">
                        <div class="col mt-4 mb-4 pb-5">
                            <p class="text-center text-3 mb-0">Kesbangpol Prov. Kalimantan Utara © 2024</p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

</body>
<!-- Vendor -->
<script src="/assets/vendor/plugins/js/plugins.min.js"></script>
<script src="/assets/vendor/particles/particles.min.js"></script>

<!-- Theme Base, Components and Settings -->
<script src="/assets/js/theme.js"></script>

<!-- Demo -->
<script src="/assets/js/demos/demo-business-consulting-4.js"></script>

<!-- Theme Custom -->
<script src="/assets/js/custom.js"></script>

<!-- Theme Initialization Files -->
<script src="/assets/js/theme.init.js"></script>
<!-- Google Maps -->
<script>
/* 
			Map Markers:
			- Get an API Key: https://developers.google.com/maps/documentation/javascript/get-api-key
			- Generate Map Id: https://console.cloud.google.com/google/maps-apis/studio/maps
			- Use https://www.latlong.net/convert-address-to-lat-long.html to get Latitude and Longitude of a specific address
			*/
(g => {
    var h, a, k, p = "The Google Maps JavaScript API",
        c = "google",
        l = "importLibrary",
        q = "__ib__",
        m = document,
        b = window;
    b = b[c] || (b[c] = {});
    var d = b.maps || (b.maps = {}),
        r = new Set,
        e = new URLSearchParams,
        u = () => h || (h = new Promise(async (f, n) => {
            await (a = m.createElement("script"));
            e.set("libraries", [...r] + "");
            for (k in g) e.set(k.replace(/[A-Z]/g, t => "_" + t[0].toLowerCase()), g[k]);
            e.set("callback", c + ".maps." + q);
            a.src = `https://maps.${c}apis.com/maps/api/js?` + e;
            d[q] = f;
            a.onerror = () => h = n(Error(p + " could not load."));
            a.nonce = m.querySelector("script[nonce]")?.nonce || "";
            m.head.append(a)
        }));
    d[l] ? console.warn(p + " only loads once. Ignoring:", g) : d[l] = (f, ...n) => r.add(f) && u().then(() => d[l](
        f, ...n))
})
({
    key: "YOUR_API_KEY",
    v: "weekly"
});

async function initMap() {
    const {
        Map,
        InfoWindow
    } = await google.maps.importLibrary("maps");
    const {
        AdvancedMarkerElement,
        PinElement
    } = await google.maps.importLibrary(
        "marker",
    );
    const map = new Map(document.getElementById("googlemaps"), {
        zoom: 14,
        center: {
            lat: -37.817240,
            lng: 144.955820
        },
        mapId: "YOUR_MAP_API_ID",
    });
    const markers = [{
        position: {
            lat: -37.817240,
            lng: 144.955820
        },
        title: "Office 1<br>Melbourne, 121 King St, Australia<br>Phone: 123-456-1234",
    }];

    const infoWindow = new InfoWindow();

    markers.forEach(({
        position,
        title
    }, i) => {
        const pin = new PinElement({
            background: "#e36159",
            borderColor: "#e36159",
            glyphColor: "#FFF",
        });
        const marker = new AdvancedMarkerElement({
            position,
            map,
            title: `${title}`,
            content: pin.element,
        });

        marker.addListener("click", ({
            domEvent,
            latLng
        }) => {
            const {
                target
            } = domEvent;

            infoWindow.close();
            infoWindow.setContent(marker.title);
            infoWindow.open(marker.map, marker);
        });
    });

}

initMap();
</script>

</html>