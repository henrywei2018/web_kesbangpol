
<x-filament-panels::page>
    <div>
        Your custom dashboard content here
    </div>
</x-filament-panels::page>