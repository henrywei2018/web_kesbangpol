<!-- resources/views/components/modals/help.blade.php -->
<div>
    <p>This is the detailed information about the title field. You can include any kind of text, links, or even images here.</p>
</div>
