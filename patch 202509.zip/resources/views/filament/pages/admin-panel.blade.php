<x-filament::page>
        <div class="grid grid-cols-12 2xl:grid-cols-4 gap-x-3 gap-y-3">
        @livewire('widgets.widget-aduan')
        @livewire('widgets.widget-s-k-t')
        @livewire('widgets.widget-s-k-l')
        @livewire('widgets.widget-s-p-t')
        </div>
</x-filament::page>