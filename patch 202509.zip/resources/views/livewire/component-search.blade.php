<div class="px-3 mt-4">
        <div class="input-group mb-3 pb-1">
            <input wire:model.live="search"
                   class="form-control box-shadow-none text-1 border-0 bg-color-grey"
                   placeholder="Pencarian Judul..." type="text">
        </div>
</div>
