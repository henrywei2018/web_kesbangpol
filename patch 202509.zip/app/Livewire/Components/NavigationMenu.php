<?php

namespace App\Livewire\Components;

use Livewire\Component;

class NavigationMenu extends Component
{
    public function render()
    {
        return view('livewire.components.navigation-menu');
    }
}
