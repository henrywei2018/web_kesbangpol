<?php

namespace App\Filament\Resources\LaporGiatResource\Pages;

use App\Filament\Resources\LaporGiatResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLaporGiat extends CreateRecord
{
    protected static string $resource = LaporGiatResource::class;
}
