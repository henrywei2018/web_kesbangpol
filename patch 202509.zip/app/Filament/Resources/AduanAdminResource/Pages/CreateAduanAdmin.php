<?php

namespace App\Filament\Resources\AduanAdminResource\Pages;

use App\Filament\Resources\AduanAdminResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAduanAdmin extends CreateRecord
{
    protected static string $resource = AduanAdminResource::class;
}
