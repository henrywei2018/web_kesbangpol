<?php

namespace App\Filament\Resources\SKLDocumentFeedbackResource\Pages;

use App\Filament\Resources\SKLDocumentFeedbackResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSKLDocumentFeedback extends CreateRecord
{
    protected static string $resource = SKLDocumentFeedbackResource::class;
}
