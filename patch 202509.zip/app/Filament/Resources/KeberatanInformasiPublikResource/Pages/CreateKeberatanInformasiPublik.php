<?php

namespace App\Filament\Resources\KeberatanInformasiPublikResource\Pages;

use App\Filament\Resources\KeberatanInformasiPublikResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKeberatanInformasiPublik extends CreateRecord
{
    protected static string $resource = KeberatanInformasiPublikResource::class;
}
