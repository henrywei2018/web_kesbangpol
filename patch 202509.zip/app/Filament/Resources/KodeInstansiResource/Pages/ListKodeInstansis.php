<?php

namespace App\Filament\Resources\KodeInstansiResource\Pages;

use App\Filament\Resources\KodeInstansiResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListKodeInstansis extends ListRecords
{
    protected static string $resource = KodeInstansiResource::class;
    

}
